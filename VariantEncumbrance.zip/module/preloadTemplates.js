export const preloadTemplates = async function () {
	const templatePaths = [
		// Add paths to "modules/VariantEncumbrance/templates"
	];

	return loadTemplates(templatePaths);
}