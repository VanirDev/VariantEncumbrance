// export class VariantEncumbranceItemData {
//     _id: string;
//     weight: number;
//     count: number;
//     totalWeight: number;
//     proficient: boolean;
//     equipped: boolean;
// }
// export class VariantEncumbranceEffectData {
//     multiply: number[];
//     add: number[];
// }
export class EncumbranceData {
}
