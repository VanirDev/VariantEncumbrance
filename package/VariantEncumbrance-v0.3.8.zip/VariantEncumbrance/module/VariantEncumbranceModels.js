export class VariantEncumbranceItemData {
}
export class VariantEncumbranceEffectData {
}
export class EncumbranceData {
}
