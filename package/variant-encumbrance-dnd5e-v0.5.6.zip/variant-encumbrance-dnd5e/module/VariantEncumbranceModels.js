export class VariantEncumbranceItemData {
}
// export class VariantEncumbranceEffectData {
//     multiply: number[];
//     add: number[];
// }
export class EncumbranceData {
}
// export class EncumbranceFlagData {
//   tier: number;
//   weight: number;
//   burrow: number;
//   climb: number;
//   fly: number;
//   swim: number;
//   walk: number;
// }
export var EncumbranceMode;
(function (EncumbranceMode) {
    EncumbranceMode["ADD"] = "add";
    EncumbranceMode["DELETE"] = "delete";
    EncumbranceMode["UPDATE"] = "update";
})(EncumbranceMode || (EncumbranceMode = {}));
