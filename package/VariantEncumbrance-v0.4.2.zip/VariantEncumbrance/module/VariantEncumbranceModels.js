export class VariantEncumbranceItemData {
}
// export class VariantEncumbranceEffectData {
//     multiply: number[];
//     add: number[];
// }
export class EncumbranceData {
}
