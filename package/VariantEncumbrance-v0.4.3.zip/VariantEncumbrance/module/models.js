export class VariantEncumbranceItemData {
}
export class VariantEncumbranceEffectData {
}
