export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "modules/variant-encumbrance-dnd5e/templates"
    ];
    return loadTemplates(templatePaths);
};
